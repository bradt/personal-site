INSTALLATION
1. Open the extracted PHP file
2. In the PHP file, update the URL to your LinkedIn profile URL
3. Upload this file to your Wordpress plugins directory
4. Activate the plugin in the Wordpress Admin
5. In the Wordpress Admin, create a new page containing:
   <!--LinkedIn hResume-->